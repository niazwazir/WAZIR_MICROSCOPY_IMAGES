
BCCD - v3 raw
==============================

This dataset was exported via roboflow.ai on February 25, 2021 at 12:24 AM GMT

It includes 364 images.
Cells are annotated in Pascal VOC format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


